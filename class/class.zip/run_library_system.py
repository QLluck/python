#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
图书馆借阅管理系统启动脚本
"""

from library_management_system.main import main

if __name__ == "__main__":
    main()
